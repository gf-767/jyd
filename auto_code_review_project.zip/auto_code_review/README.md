
# Auto Code Review System

This is an automated code review system that performs security, performance, and style checks. It uses multiple agents to analyze the code and generate pull requests with fix suggestions.

## Installation
1. Clone the repository.
2. Install the requirements using `pip install -r requirements.txt`.

## Usage
- Run `python core/coordinator.py` to start the code review process.
